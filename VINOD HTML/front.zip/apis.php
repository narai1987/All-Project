<?php
require_once('dbaccess.php');



class apiClass extends DbAccess {
    public $view='';
	public $name='api';
	
	function tripsByType($view) {
		$tripType = $_REQUEST['tripType'];
		$sql="select t.id, t.image, ts.origin,ts.destination,bs.boat_name,c.country from trips t JOIN trip_types tt ON t.trip_type_id = tt.id JOIN trip_specifications ts ON t.id = ts.trip_id JOIN boats b ON t.boat_id = b.id JOIN boatspecifications bs ON b.id = bs.boat_id JOIN countries c ON t.country_id = c.id WHERE t.status = '1' and ts.language_id = '1' and bs.language_id = '1' and t.trip_type_id = '".$tripType."'";
		$this->Query($sql);
		if(!$this->rowCount()) {
			$str['result'] = array();
		}
        else {
    		$i=0;
    		$str = '';
    		$results = $this->fetchArray();
    		foreach($results as $result) {	
    			
    			$url = "http://".$_SERVER['HTTP_HOST']."/idive/admin/".$result['image'];
    			$str['result'][$i]['tripID'] = $result['id']; 
    			$str['result'][$i]['tripTitle'] = $result['trip_title']." By ".$result['boat_name']; 
    			$str['result'][$i]['tripPlace'] = $result['origin']?$result['origin']:'';			
    			$str['result'][$i]['tripImageURL'] = $url; 
    			
    			$i++;
    		}
        }
		echo json_encode($str);
		die; 
	}
	
	function tripsByCategory() {
		if($_REQUEST['categoryType']=='1' or $_REQUEST['categoryType']=='2' or $_REQUEST['categoryType']=='3') {
			$categoryType = " and ".($this->tripCategory($_REQUEST['categoryType']));		
			
            $sql="select t.id, t.image, ts.origin,ts.destination,bs.boat_name,c.country from trips t JOIN trip_types tt ON t.trip_type_id = tt.id JOIN trip_specifications ts ON t.id = ts.trip_id JOIN boats b ON t.boat_id = b.id JOIN boatspecifications bs ON b.id = bs.boat_id JOIN countries c ON t.country_id = c.id WHERE t.status = '1' and ts.language_id = '1' and bs.language_id = '1' ".$categoryType;
			$this->Query($sql);            
    		$str = '';
			if(!$this->rowCount()) {
				$str['result'] = array();
			}
            else {
    			$i=0;
    			$results = $this->fetchArray();
    			foreach($results as $result) {	
    				$url = "http://".$_SERVER['HTTP_HOST']."/idive/admin/".$result['image'];
    				$str['result'][$i]['tripID'] = $result['id']; 
    			$str['result'][$i]['tripTitle'] = $result['trip_title']." By ".$result['boat_name']; 
    				$str['result'][$i]['tripPlace'] = $result['origin']?$result['origin']:'';			
    				$str['result'][$i]['tripImageURL'] = $url; 
    				
    				$i++;
    			}
            }
		}
		else {
			$str['result'] = array();	
		}
		echo json_encode($str);
		die; 
	}
	function tripGallery() {
		
		$id = $_REQUEST['tripID'];
		$q_gallery = "SELECT * FROM   trip_gallery WHERE trip_id = '".$id."' "; 
		$this->Query($q_gallery);
		
		if(!$this->rowCount())
			$str['result'] = array();
		$i=0;
		$str = '';
		$results = $this->fetchArray();
		if(count($results)) { 
			foreach($results as $result) {	
				$url = $result['image']?("http://".$_SERVER['HTTP_HOST']."/idive/admin/media/trips/".$result['trip_id']."/".$result['image']):("http://".$_SERVER['HTTP_HOST']."idive/admin/media/trips/trip.jpg");
				$str['result'][$i]['tripImageURL'] = $url; 
				$i++;
			}
		}
		else {
			$str['result'] = array();
		}
		echo json_encode($str);
		die; 	
	}
     function tripDetail() {
		$tripID = $_REQUEST['tripID'];
		$sql="select t.id,ts.specification, t.image, ts.origin,ts.destination,bs.boat_name,c.country from trips t 
		JOIN trip_types tt ON t.trip_type_id = tt.id 
		JOIN trip_specifications ts ON t.id = ts.trip_id 
		JOIN boats b ON t.boat_id = b.id 
		JOIN boatspecifications bs ON b.id = bs.boat_id 
		JOIN countries c ON t.country_id = c.id 
		WHERE t.status = '1' and ts.language_id = '1' and bs.language_id = '1' and t.id = '".$tripID."'";
		$this->Query($sql); 
        if(!$this->rowCount())
			$str['result'] = array();
		$i=0;
		$str = '';
		$results = $this->fetchArray();
		/*if(count($results)) { 
			foreach($results as $result) {	
				$url = $result['image']?("admin/media/trips/".$result['trip_id']."/".$result['image']):("admin/media/trips/trip.jpg");
				$str['result'][$i]['tripID'] = $result['id']; 
				$str['result'][$i]['tripTitle'] = $result['destination'].",".$result['country'].",".$result['boat_name']; 
				$str['result'][$i]['tripPlace'] = $result['origin']?$result['origin']:'';			
				$str['result'][$i]['tripImageURL'] = $url;
				$i++;
			}
		}
		else {
			$str['result'] = array();
		}
		echo json_encode($str);
		die;*/
		require_once("views/".$this->name."/tripDetail.php"); 
    }
	function tripCategory($type) {
		switch($type) {
			case "1":
			return "lastminut = '1'";
			break;
			case "2":
			return "upcoming = '1'";
			break;
			case "3":
			return "popular = '1'";
			break;
		}		
		
	}
}