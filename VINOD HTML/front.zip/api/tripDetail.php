<div id="container">
<!--<div id="header"></div>-->

<div id="content">
<div class="promotion_list">

<div class="promo_box">
<div class="img_container"><img src="assets/webview/images/boat.png" alt="thumb" /></div>
<div class="promo_cont airline_next"><span>4D/4N Similan Island<br />
<em>Richelieu Rock</em></span> <em><a href="#"><img src="assets/webview/images/bookbtn.png" width="104" alt="" /></a></em></div>
</div>

</div>
<div class="my_account">

<div class="white_base">


<div id="example-two">
<div class="black_base">
<div class="black_title"><p class="pointer"><em class="left">Jumeirah, Dubai, UAE</em> <span class="right">$2039.00</span></p>
<p class="star">
<a href="#" class="yellow_star">&nbsp;</a>
<a href="#" class="grey_star">&nbsp;</a>
<a href="#" class="grey_star">&nbsp;</a>
<a href="#" class="grey_star">&nbsp;</a>
<a href="#" class="grey_star">&nbsp;</a></p>
</div>


    		<ul class="nav">
                
                <li class="nav-three"><a href="#jquerytuts2">Review</a></li>
                <li class="nav-two"><a href="#core2">Specification</a></li>
                <li class="nav-one"><a href="#featured2" class="current">Description</a></li>
                <!--<li class="nav-four last"><a href="#classics2">Classics</a></li>-->
            </ul>
            </div>
    		
    		<div class="list-wrap">            
            
            <div id="featured2" class="desc_para">
            <?php echo $results[0]['specification'];?>
           <!-- <p>Welcome to the pride of the Andaman sea! The MV Deep Andaman Queen, new refurbished in the year of 2012, is a 28.5-meters long and 7-meters wide, twin-engine steel hull motor boat, with the highest safety standards on board. She will be operating along Thailand's western coast and offering incredible </p>
            <p>Welcome to the pride of the Andaman sea! The MV Deep Andaman Queen, new refurbished in the year of 2012, is a 28.5-meters long and 7-meters wide, twin-engine steel hull motor boat, with the highest safety standards on board. She will be operating along Thailand's western coast and offering incredible </p>
            <p>Welcome to the pride of the Andaman sea! The MV Deep Andaman Queen, new refurbished in the year of 2012, is a 28.5-meters long and 7-meters wide, twin-engine steel hull motor boat, with the highest safety standards on board. She will be operating along Thailand's western coast and offering incredible </p>
            <p>Welcome to the pride of the Andaman sea! The MV Deep Andaman Queen, new refurbished in the year of 2012, is a 28.5-meters long and 7-meters wide, twin-engine steel hull motor boat, with the highest safety standards on board. She will be operating along Thailand's western coast and offering incredible </p>-->
            </div>          
            
            <div id="core2" class="desc_para hide">
            <h2>Package Include:</h2>
            <p>Welcome to the pride of the Andaman sea! The MV Deep Andaman Queen, new refurbished in the year of 2012, is a 28.5-meters long and 7-meters wide, twin-engine steel hull motor boat, with the highest safety standards on board. She will be operating along Thailand's western coast and offering incredible </p>
            <p>Welcome to the pride of the Andaman sea! The MV Deep Andaman Queen, new refurbished in the year of 2012, is a 28.5-meters long and 7-meters wide, twin-engine steel hull motor boat, with the highest safety standards on board. She will be operating along Thailand's western coast and offering incredible </p>
            <p>Welcome to the pride of the Andaman sea! The MV Deep Andaman Queen, new refurbished in the year of 2012, is a 28.5-meters long and 7-meters wide, twin-engine steel hull motor boat, with the highest safety standards on board. She will be operating along Thailand's western coast and offering incredible </p>
            <p>Welcome to the pride of the Andaman sea! The MV Deep Andaman Queen, new refurbished in the year of 2012, is a 28.5-meters long and 7-meters wide, twin-engine steel hull motor boat, with the highest safety standards on board. She will be operating along Thailand's western coast and offering incredible </p>
            </div>
            
            <div id="jquerytuts2" class="desc_para hide">
            <h2>Customer reviews:</h2>
            <div class="date"><span>09/Oct/2013</span></div>
            <div class="review">
            <p>Welcome to the pride of the Andaman sea! The MV Deep Andaman Queen, new refurbished in the year of 2012, is a 28.5-meters long and 7-meters wide, twin-engine steel hull motor boat, with the highest safety standards on board. She will be operating along Thailand's western coast and offering incredible </p>
            <p>Welcome to the pride of the Andaman sea! The MV Deep Andaman Queen, new refurbished in the year of 2012, is a 28.5-meters long and 7-meters wide, twin-engine steel hull motor boat, with the highest safety standards on board. She will be operating along Thailand's western coast and offering incredible </p>
           
            </div>
            
            
            
            </div>
        		 
    		 </div> <!-- END List Wrap -->
		 
		 </div> <!-- END Organic Tabs (Example One) -->
</div>



</div>

</div>
</div>