<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>jQuery UI Datepicker - Restrict date range</title>
  <link rel="stylesheet" href="newCal/jquery-ui.css">
<script src="newCal/jquery-1.9.1.js"></script>
<script src="newCal/jquery-ui.js"></script>
  <script>
  /*$(function() {
    $( "#datepicker" ).datepicker({ minDate: 0, maxDate: "+1M +10D" });
  });*/
  /*$(function() {
    $( "#datepicker" ).datepicker({ minDate: new Date(2014, 02, 10), maxDate: new Date(2014, 02, 15) });
  });*/
  
  /* create an array of days which need to be disabled */
var disabledDays = ["2014-02-21","2014-02-22","2014-02-23","2014-02-24","2014-02-25","2014-02-13","2014-02-10","2014-02-11","2014-02-12","2014-02-14"];
alert(disabledDays.indexOf("2014-02-02"));
/* create datepicker */
$(function() {
	$('#datepicker').datepicker({
		beforeShowDay: function(date){
        var string = $.datepicker.formatDate('yy-mm-dd', date);
        return [ disabledDays.indexOf(string) == -1 ]
    },
      onClose: function( selectedDate ) {
        $( "#datepicker7" ).datepicker( "option", "minDate", selectedDate );
      }
	});
});
  
  
$(function() {
	$('#datepicker7').datepicker({
		beforeShowDay: function(date){
        var string = $.datepicker.formatDate('yy-mm-dd', date);
        return [ disabledDays.indexOf(string) == -1 ]
    }
	});
});
  
  
  </script>
</head>
<body>
 
<p>Date: <input type="text" id="datepicker"></p>
<p>Date: <input type="text" id="datepicker7"></p>
 
 
</body>
</html>