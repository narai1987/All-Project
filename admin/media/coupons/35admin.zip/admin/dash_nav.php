<div id="nav_p">

  <div id="nav">
  
     <div class="top_menu">
     
     
                    <ul>
            
                       <li><a href="admin_dashboard.php">DashBoard Home</a></li>
                       
                       <li><a href="http://mgmsarni.com/index.php">Website Home Page</a></li>
                       
                       
              
                    </ul>
     
     
     </div>
  
  </div>

</div>