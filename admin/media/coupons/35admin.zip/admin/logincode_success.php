<?php



   $conn = mysql_connect("localhost","mgmsaqib","12345");
   $db   = mysql_select_db("mgm_sarni",$conn);

	session_start();



	$type = $_REQUEST['select'];
	$uname = $_REQUEST['username'];
	$pass = $_REQUEST['password'];


echo"not insert";
if($type=="Student")
{
	$sql="select * from registration where Uname='$uname'and Password='$pass' and RegType='Student'  and Activation IS NULL ";
	$qury=mysql_query($sql);
	$numrows=mysql_num_rows($qury);
	if($numrows==1)
	{
		session_register("Uname");
		session_register("Password");
		session_register("select");
		
			
		$_SESSION['u_type']=$type;
		$_SESSION['u_name']=$uname;

		$i=$_SESSION['u_type'];
			echo ("<script language='javascript'>window.location='student_dashboard.php'</script> ");
	
			
		

	}
	

}


elseif($type=="Faculty")
{
	$sql="select * from faculty_registration where UserName='$uname'and Password='$pass' and RegType='$type'";
	$qury=mysql_query($sql);
	$numrows=mysql_num_rows($qury);
	if($numrows==1)
	{
		session_register("Uname");
		session_register("Password");
		session_register("select");
		
			
	    $_SESSION['u_type']=$type;
	    $_SESSION['u_name']=$uname;

    	$i=$_SESSION['u_type'];
	
		echo ("<script language='javascript'>window.location='student_dashboard.php'</script> ");
		

	}
	

}



?>