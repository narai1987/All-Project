<div id="nav_p">

  <div id="nav">
  
     <div class="top_menu">
     
     
        <ul>
            
                       <li><a href="index.php">Home</a></li>
                       
                      
                       
                       <li><a href="about_school.php" >About Us</a>
                       
                           <div class="vinod">
                            <p>
                            <a href="about_school.php" style="border-bottom:1px solid #bdbdbd; color:#000;">About School</a>
                            <!--<a href="vis_mis.php" style="border-bottom:1px solid #dfe0e3; color:#000;">Vision & Mission</a>-->
                            <a href="the_patron.php" style="border-bottom:1px solid #dfe0e3; color:#000;">The Patron</a>
                            <a href="the_founder.php" style="border-bottom:1px solid #dfe0e3; color:#000;">The Founder</a>
                            <a href="chairman_mess.php" style="border-bottom:1px solid #dfe0e3; color:#000;">Chairman's Message</a>
                            <a href="principal_mess.php"  style="border-bottom:1px solid #dfe0e3; color:#000;">Principal's Message</a>
                            <a href="smc_member.php" style="color:#000;">SMC Members</a>
                            </p>
                       </div>
                       
                       </li>
            
                       <li><a href="curriculam.php">Academics</a>
                     
                           <div class="vinod">
                            <p>
                            <a href="curriculam.php" style="border-bottom:1px solid #bdbdbd; color:#000;">Curriculam</a>  
                            <a href="activities.php" style="border-bottom:1px solid #dfe0e3; color:#000;">Activities</a>
                            <a href="co_activities.php" style="border-bottom:1px solid #dfe0e3; color:#000;">Co-Curricular Activities</a>
                            <a href="examination.php" style="color:#000;">Examination</a>
                           
                            </p>
                       </div>
               
                       </li>
                       
                      
                       <li><a href="admission.php">Admission</a></li>
                  
                       <li><a href="facilities.php">Facilities</a></li>
                       
                        <li><a href="faculty.php">Faculty</a></li>
                       
                       <li><a href="alumni.php">Alumni</a></li>
               
                       
                       
                       <li><a href="infra.php">Infrastructure</a></li>
                       
                       <li><a href="news_events.php">News & Events</a></li>
                       
                       <li><a href="career.php">Career With Us</a></li>
                       
                      
                 
                    </ul>
     
     
     </div>
  
  </div>

</div>