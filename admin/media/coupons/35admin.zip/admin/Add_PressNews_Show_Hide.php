<?php
require "config.php";
$a = $_REQUEST['id'];

		 $sql="SELECT * FROM  pressnews where PressNewsId='$a' " ;
         $result = mysql_query($sql);
$row = mysql_fetch_array($result);

  $ShowHide=$row[ShowHide];


 if($ShowHide=="D")
{
$sql= "update pressnews set ShowHide='A' where PressNewsId='$a'";

$qury = mysql_query($sql);
	
	
			if(!$qury )
			{echo "Not";
			echo mysql_error();}
			else
			{
			echo ("<script language='javascript'>window.location='add_Press_News.php'</script>");
			}
		

}

else

{
	$sql1 = "update pressnews set ShowHide='D' where PressNewsId='$a'";

	$qury = mysql_query($sql1);
	
	
			if(!$qury )
			echo mysql_error();
			else
			{
			echo ("<script language='javascript'>window.location='add_Press_News.php'</script>");
			}
		

}

?>