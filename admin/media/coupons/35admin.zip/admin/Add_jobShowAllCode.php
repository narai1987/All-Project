<?php
require "config.php";
	 { 
		 $sql="SELECT * FROM new_jobpost";
         $result = mysql_query($sql);
#echo "<table border='1' align='center'>
#<tr>
#<th>Jobs Tittle</th>
#<th>Qualification</th>
#<th>Work Experience</th>
#<th>edit</th>
#<th>delete</th>
#</tr>";


  echo "<table cellspacing='1' cellpadding='1' class='table'>
            
                <tr class='tab_head'>
				<td width='5%' ><input type='checkbox' /></td>
                  <td width='29%'>Jobs Tittle</td>
                    <td width='25%'  class='pad'>Qualification</td>
					<td width='25%'  class='pad'>Work Experience</td>
                    <td width='10%'>Edit</td><td width='11%'>Delete</td>
                </tr>";
$tr=0;
while($row = mysql_fetch_array($result))
  {
	  
 echo "<table cellspacing='1' cellpadding='1' class='table'>";
            
             echo "   <tr class='".(($tr%2==0)?"even":"odd")."'>";
                echo "    <td width='5%' ><input type='checkbox' /></td>";
                  echo "  <td width='29%'>". $row["job_title"] ."</td>";
                   echo " <td width='25%'  class='pad'>". $row["qualiy_ca"] ."</td>";
				   echo " <td width='25%'  class='pad'>". $row["work_exp"] ."</td>";
                    echo " <td valign='middle' width='10%'><a href='admin_edit_job.php?id={$row[0]}'><img src='images/edit.png'/></a></td>";
echo " <td width='11%'><a href='Admin_Deletejob.php?id={$row[0]}' ><img src='images/del.png' /></a></td>";
               echo " </tr>";



  #echo "<tr>";
  #echo "<td nowrap='nowrap'>" . $row[0] . "</td>";
  #echo "<td nowrap='nowrap'>" . $row[1] . "</td>";
  #echo "</tr>";
  $tr++;
  }
echo "</table>";

		 }




?>