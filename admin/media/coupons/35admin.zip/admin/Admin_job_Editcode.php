<?php

require "config.php";



	$jbtitle= $_REQUEST['JobId'];
	$jbqualiy= $_REQUEST['qualiy_ca'];
	$jbexp= $_REQUEST['work_exp'];
	
	 
	if (($jbtitle!=""))
	 {
	$sql = "Update  new_jobpost Set JobId='$jbtitle',Date=now() Where JobId='$jbtitle'";
	$qury = mysql_query($sql);
	
	
		if(!$qury )
			echo mysql_error();
		else
		{
	echo "(<script language='javascript'>window.alert('Job Successfuly Updated'),window.location='add_new_job.php'</script>)";
			
		}
	 }
	
 
 else
	 { 
	echo "(<script language='javascript'>window.alert('please fill all details'),window.location='add_new_job.php'</script>)";
			 }




?>