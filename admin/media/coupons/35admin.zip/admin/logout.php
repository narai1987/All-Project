<?php
session_start();
session_destroy();
echo ("<script language='javascript'>window.alert('You are successfully logout.'),window.location='login.php'</script>"); 
?>