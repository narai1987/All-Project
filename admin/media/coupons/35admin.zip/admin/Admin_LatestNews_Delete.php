<?php
require "config.php";
require "admin_dashboard.php";
$a = $_REQUEST['id'];

 $sql = "delete from latest_news where NewsId='$a'";
	$qury = mysql_query($sql);
		
		if(!$qury )
			echo mysql_error();
		else
		{
	echo "(<script language='javascript'>window.alert('You have successfuly deleted this news'),window.location='admin_dashboard.php'</script>)";
		}
		

?>