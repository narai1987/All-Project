<!-- top green strip -->
<div id="top_p">

  <div id="top"></div>

</div>
<!-- top green strip end-->


<!-- top white header -->
<div id="header_p">

  <div id="header">
  
      <div class="logo left"></div>
      
      <div class="top_link_row right">
      
                             <div class="top_link right">
                   
                                <a href="download.php"  title="Downloads"><img src="images/download.png" /></a><br />
                       
                            </div>
                            
                             <div class="top_link right">
                   
                                <a href="contact.php"  title="Contact Us"><img src="images/contact.png" /></a><br />
                  
                            </div>
                    
                            <div class="top_link right">
                   
                                <a href="index.php"  title="Homepage"><img src="images/home.png" /></a><br />
                   
                            </div>
             
                            <div class="clear"></div>
                            
                             <div  class="clock"><span id="clock"></span></div>
                  
                            </div>
      
      <div class="clear"></div>
  
  </div>

</div>
<!-- top white header end-->