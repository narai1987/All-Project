<?php
require "config.php";
	 { 
		 $sql="SELECT * FROM latest_news order by Date Desc " ;
         $result = mysql_query($sql);

  echo "<table cellspacing='1' cellpadding='1' class='table'>
            
                <tr class='tab_head'>
           
                    <td width='60%' align='left' class='pad'>News Details</td>
                  
                    <td width='10%'>Edit</td>
					<td width='10%'>Show/Hide</td>
					<td width='10%'>Delete</td>
                </tr>";
$tr=0;
while($row = mysql_fetch_array($result))
  {

 echo "<table cellspacing='1' cellpadding='1' class='table'>";
            
             echo "   <tr class='".(($tr%2==0)?"even":"odd")."'>";
                  echo "  <td width='60%' align='left' class='pad'>". $row[News] ."</td>";
                   
                     
                  echo "   <td valign='middle' width='10%'><a href='Admin_LatestNews_Edit.php?id=$row[NewsId]'><img src='images/edit.png' /></a></td>";
				  
				  if ($row[3]=="D")
				 {  echo "   <td valign='middle' width='10%'><a href='Admin_LatestNews_Show_Hide.php?id=$row[NewsId]'><img src='images/deactive.png' /></a></td>";}
				   else
				   { echo "   <td valign='middle' width='10%'><a href='Admin_LatestNews_Show_Hide.php?id=$row[NewsId]'><img src='images/active.png' /></a></td>";}
				  
                  echo"  <td width='10%'><a href='Admin_LatestNews_Delete.php?id=$row[NewsId]'><img src='images/del.png' /></a></td>";
               echo " </tr>";
#echo "<tr>";
  #echo "<td nowrap='nowrap'>" . $row[0] . "</td>";
  #echo "<td nowrap='nowrap'>" . $row[1] . "</td>";
  #echo "</tr>";
  $tr++;
  
 
  }
echo "</table>";

		 }




?>