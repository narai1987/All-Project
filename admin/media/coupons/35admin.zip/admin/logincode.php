<?php



  require "Config.php";

	session_start();



	$type = $_REQUEST['select'];
	$uname = $_REQUEST['username'];
	$pass = $_REQUEST['password'];
	#echo $uname;
	
	


	if($type=="Select Login Type")
	{	
	$field="Login type";
	$status=1;
	}
	if($uname=="" ||$pass=="")
	{
	$field="uname or password";
	$status=1;
	}

if($uname!="" ||$pass!="")
{
	if($status==0 && $type=="Student")
	{
	$sql="select * from registration where Uname='$uname'and Password='$pass' and RegType='Student'  and Activation = 'NULL' ";
	$qury=mysql_query($sql);
	$numrows=mysql_num_rows($qury);
	if($numrows==1)
	{
		session_register("Uname");
		session_register("Password");
		session_register("select");
		
			
		$_SESSION['u_type']=$type;
		$_SESSION['u_name']=$uname;

		$i=$_SESSION['u_type'];
			echo ("<script language='javascript'>window.location='student_dashboard.php'</script> ");
	
			
		

	}
	else
	{
		require "login.php";
		echo "(<script language='javascript'>window.alert('Uname,Password or type is incorrect   ')</script>)";
			
		
		
	}

	}


	elseif($status==0 && $type=="Faculty")
	{
	$sql="select * from faculty_registration where UserName='$uname'and Password='$pass' and RegType='$type'";
	$qury=mysql_query($sql);
	$numrows=mysql_num_rows($qury);
	if($numrows==1)
	{
		session_register("Uname");
		session_register("Password");
		session_register("select");
		
			
	    $_SESSION['u_type']=$type;
	    $_SESSION['u_name']=$uname;

    	$i=$_SESSION['u_type'];
	
	#echo  $_SESSION['u_name'];
		echo ("<script language='javascript'>window.location='faculty_dashboard.php'</script> ");
		

	}
	else
	{
			require "login.php";
		echo ("<script language='javascript'>window.alert('Uname,Password or type is incorrect ')</script> ");	
	}

}

elseif($status==0 && $type=="Admin")
	{
	$sql="select * from admin_acc where Uname='$uname'and Password='$pass' and Type='$type'";
	$qury=mysql_query($sql);
	$numrows=mysql_num_rows($qury);
	if($numrows==1)
	{
		session_register("Uname");
		session_register("Password");
		session_register("select");
		
			
	    $_SESSION['u_type']=$type;
	    $_SESSION['u_name']=$uname;

    	$i=$_SESSION['u_type'];
	
		echo ("<script language='javascript'>window.location='admin_dashboard.php'</script> ");
		

	}
	else
	{
			require "login.php";
		echo ("<script language='javascript'>window.alert('Uname,Password or type is incorrect  ')</script> ");	
	}

}



	else
	{
		require "login.php";
	echo ("<script language='javascript'>window.alert('please fill $field ')</script>");
	}

}
else
require "login.php";
	



?>