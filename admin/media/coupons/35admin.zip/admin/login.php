<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Welcome to MGMSARNI</title>

<link href="css/style.css" rel="stylesheet" type="text/css" />



<!--- clock -->


<script>

/*
Live Date Script- 
© Dynamic Drive (www.dynamicdrive.com)
For full source code, installation instructions, 100's more DHTML scripts, and Terms Of Use,
visit http://www.dynamicdrive.com
*/


var dayarray=new Array("Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday")
var montharray=new Array("January","February","March","April","May","June","July","August","September","October","November","December")

function getthedate(){
var mydate=new Date()
var year=mydate.getYear()
if (year < 1000)
year+=1900
var day=mydate.getDay()
var month=mydate.getMonth()
var daym=mydate.getDate()
if (daym<10)
daym="0"+daym
var hours=mydate.getHours()
var minutes=mydate.getMinutes()
var seconds=mydate.getSeconds()
var dn="AM"
if (hours>=12)
dn="PM"
if (hours>12){
hours=hours-12
}
if (hours==0)
hours=12
if (minutes<=9)
minutes="0"+minutes
if (seconds<=9)
seconds="0"+seconds
//change font size here
var cdate="<small><font color='760000' size='2' face='Arial'><i>Welcome Guest</i> | "+dayarray[day]+", "+montharray[month]+" "+daym+", "+year+" | "+hours+":"+minutes+":"+seconds+" "+dn
+"</font></small>"
if (document.all)
document.all.clock.innerHTML=cdate
else if (document.getElementById)
document.getElementById("clock").innerHTML=cdate
else
document.write(cdate)
}
if (!document.all&&!document.getElementById)
getthedate()
function goforit(){
if (document.all||document.getElementById)
setInterval("getthedate()",1000)
} 

</script>

<!-- clock end -->


</head>

<body onLoad="goforit()">

<form action="logincode.php" method="post">

<div id="page">

<!-- header -->
<?php include_once "header.php"; ?> 

<!-- header  end-->

<!-- top navigation -->
<?php include_once "nav.php"; ?> 
<!-- top navigation end-->


<!-- main container -->
<div id="container_p">

   <div id="container">
   
      
       
        <!-- row for matter & quick links -->
       
           <div class="row" style="margin-top:10px; margin-bottom:10px;">
           
             <!-- left section starts -->
             
               
                     <div class="login_box">
                     
                        <div class="head"><h2>Admin Login</h2></div>
                        
                        <div class="matter" style="margin:10px auto">
                        
                        <div align="center">
                        
                      <table width="90%" border="0" cellspacing="0" cellpadding="0">
                                  <tr>
                                    <td align="left" valign="middle"><img src="images/login_icon.png" /></td>
                                     <td align="right" valign="top">
                                    
                                    
                                        <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                              <tr>
                                                <td align="left" valign="middle" height="15px"></td>
                                                <td align="left" valign="middle" height="15px"></td>
                                              </tr>
                                              <tr>
                                                <td align="left" valign="middle">User name</td>
                                                <td align="left" valign="middle"><input type="text" class="text_box"  name="username"  id="username"  maxlength="50" size="50"/></td>
                                              </tr>
                                              <tr>
                                                <td align="left" valign="middle">Password</td>
                                                <td align="left" valign="middle"><input type="password" class="text_box" name="password"  id="password"  maxlength="50" size="50" /></td>
                                              </tr>
                                              
                                               <tr>
                                                    <td>Login Type</td>
                                                    
                                                    <td><select name="select" id="select" class="text_box">
                                                      <option selected="selected">Select Login Type</option>
                                                      
                                                      <option>Admin</option>
                                                    </select> 
                                              
                                                        </td>
                                                  </tr>
                                              <tr>
                                                <td></td>
                                                <td align="left"><a href="#"><input type="image" src="images/submit.png" style="margin-top:5px;" /></a></td>
                                              </tr>
                                            </table>
                                                
                                    </td>
                                  </tr>
                                </table>

                           </div>
                         
                        </div>
         
                     </div>
                  
               
             <!-- left section end -->
               
             
               
           
           </div>
       
        <!-- row for matter & quick links end-->
  
   </div>

</div>
<!-- main container end -->

<!-- footer section -->

<?php include_once "footer.php"; ?>
  
<!-- footer section end-->

</div>

</form>

</body>
</html>
