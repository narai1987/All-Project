<?php
require "config.php";
	 { 
		 $sql="SELECT * FROM pressnews Order By Date Desc" ;
         $result = mysql_query($sql);

  echo "<table cellspacing='1' cellpadding='1' class='table'>
            
                 <tr class='tab_head'>
                   
                    
                    <td width='50%' align='left' class='pad'>Press News Details</td>
<td width='20%' align='center'>FileName</td>   
                <td width='10%'>Show/Hide</td>
<td width='10%'>Edit</td><td width='10%'>Delete</td>
                </tr>";
$tr=0;
while($row = mysql_fetch_array($result))
  {

 echo "<table cellspacing='1' cellpadding='1' class='table'>";
            
             echo "   <tr class='".(($tr%2==0)?"even":"odd")."'>";
                  echo "  <td width='50%'  align='left' class='pad'>". $row[PressNews] ."</td>";
                    echo "  <td width='20%' align='left' class='pad'>". $row[PressFileName] ."</td>";
						  if ($row[	ShowHide]=="D")
				 {  echo "   <td valign='middle' width='10%'><a href='Add_PressNews_Show_Hide.php?id=$row[PressNewsId]'><img src='images/deactive.png' /></a></td>";}
				   else
				   { echo "   <td valign='middle' width='10%'><a href='Add_PressNews_Show_Hide.php?id=$row[PressNewsId]'><img src='images/active.png' /></a></td>";}
             
                  echo "   <td valign='middle' width='10%'><a href='add_press_news_edit.php?id=$row[PressNewsId]'><img src='images/edit.png' /></a></td>
                    <td><a href='add_Press_Newsdelete.php?id=$row[PressNewsId]'><img src='images/del.png' /></a></td>";
               echo " </tr>";
			   
  #echo "<tr>";
  #echo "<td nowrap='nowrap'>" . $row[0] . "</td>";
  #echo "<td nowrap='nowrap'>" . $row[1] . "</td>";
  #echo "</tr>";
  $tr++;

  }
echo "</table>";

		 }




?>