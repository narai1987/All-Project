
              <div id="footer_p">
              
                  <div id="footer">
                  
                     <!-- information link -->
                 <div class="foot_link left">
                  <div class="f_head">Informations</div>
                  
                  <div class="f_link">
                  
                       <ul>
                        
                          <li><a href="about_school.php">About Us</a></li>
                          
                          <li><a href="career.php">Career With Us</a></li>
                          
                          <li><a href="download.php">Downloads</a></li>
                          
                          <li><a href="http://infranix.net:2095/cpsess5663283284/horde/index.php">Web Mail</a></li>
                       
                       </ul>
                  
                  
                  </div>
                  </div>
                  <!-- information link end -->
                  
                  
                <!-- connect link -->  
                 
                        <div class="foot_link left" style="margin-left:15px;">
                  <div class="f_head">Connect With Us</div>
                  
                  <div class="f_link">
                  
                     <a href="javascript:void(0)"><img src="images/facebook.png" /></a> <a href="javascript:void(0)"><img src="images/blog.png" /></a>  <a href="javascript:void(0)"><img src="images/twitter.png" /></a>   
                  
                  </div>
                  
                  
                  </div>
                  
                  
                  <!-- connect link end -->
                  
                  <!-- Extras link -->
                 <div class="foot_link left" style="margin-left:15px; width:250px">
                  <div class="f_head">Our Address</div>
                  
                  <div class="f_add">
                  
                       M. G. M .SENIOR SECONDARY SCHOOL
<br />Bagdona, Pathakheda (P.O.)<br />Betul (Dt.) M.P. 460 449<br />Phone: 0714-6250221<br />
E-mail:contact@mgmsarni.com
                  
                  
                  </div>
                  </div>
                  <!-- Extras link end -->
                  
                  
                  
                    <!-- connect link -->  
                  <div class="location right" style="margin-right:5px;">
                  
                  <div  class="f_head">Our Location</div>
                  
                  <div class="f_add">
                  
                    <iframe width="300" height="130" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.co.in/maps?f=q&amp;source=s_q&amp;hl=en&amp;geocode=&amp;q=M.+G.+M+.SENIOR+SECONDARY+SCHOOL+Bagdona,+Pathakhera+(P.O.)+Betul+(Dist.)+M.P.+460+449&amp;aq=&amp;sll=21.125498,81.914063&amp;sspn=24.79385,28.256836&amp;ie=UTF8&amp;ll=21.125498,81.914063&amp;spn=0.024379,0.027595&amp;t=m&amp;z=14&amp;output=embed"></iframe>
     
                  </div>
                  
                  </div>
                  
                  <!-- connect link end -->
                  
                  
                  <div class="clear"></div>
                  
                  <div id="copy">
             
                <div class="copy_text left">All Copyright © Reserved by mgmsarni.com | Design & Developed By Mohd Saqib</div>
                
                <div class="right" style="margin-top:25px;"><b style="color:#fff; font-family:Arial, Helvetica, sans-serif;">Visitor No.</b><a href="http://www.designwala.co.in/">
<img src="http://www.easycounter.com/counter.php?saqibm"
border="0" alt="Web Site Hit Counters"></a>
</div>

                <div class="clear"></div>
    
             </div>
                  
                  
                  </div>
              
              </div>