<!-- top green strip -->
<div id="top_p">

  <div id="top"></div>

</div>
<!-- top green strip end-->


<!-- top white header -->
<div id="header_p">

  <div id="header">
  
      <div class="logo left"></div>
      
      <div class="top_link_row right">
      
                             <div class="top_link right">
                   
                                <table width="175" cellpadding="0" cellspacing="0">
                          
                          
                                <tr>
                                
                                  <td width="154" align="right">
                                       <table  cellpadding="4" cellspacing="4" class="tab">
                                               <tr>
                                                    <td width="6%">
                                                    <img src="images/man_image.png"  />
                                                    </td>
                                                    <td align="left" valign="middle">
                                                        <div><span>Adminstrator</span></div>
                                                        
                                                        <div><span>MGM, Sarni</span></div>
                                                    </td>
                                              </tr>
                                    </table>
                                
                                </td>
                                
                                <!--<td width="69">
                                  <a href="index.php"><img src="images/home.png" /></a><br />
                                
                                  <a href="admin_dashboard.php">DashBoard</a>
                                  
                                </td>-->
                                
                                <td width="33">
                                  <a href="logout.php"><img src="images/logout.png" /></a><br />
                                
                                  <a href="logout.php">Logout</a>
                                  
                                </td>
                                
                                </tr>
                                
                          </table>
                          
                            
                             
                            </div>
                           
                         
                            
                            
      
      <div class="clear"></div>
  
  </div>

</div>
<!-- top white header end-->