<?php

require 'config.php';

$a = $_REQUEST['id'];

$sql="select * from pressnews where PressNewsId='$a'";

	$qury=mysql_query($sql);
	$numrows=mysql_num_rows($qury);
	if($numrows==1)
	{
	
		while($row=mysql_fetch_array($qury))
		{
			
			$pressnewsid=$row[PressNewsId];
			$pessnews=$row[PressNews];
			$$pressfilename=$row[PressFileName];
					
			
		}
	
	}

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Chhattisgarh Engineering College</title>
<link href="css/style.css" rel="stylesheet" type="text/css" />
<link type="text/css" href="css/menu.css" rel="stylesheet" />
<link href="css/styles.css" rel="stylesheet" type="text/css" />

    
</head>

<body>
<form action="add_press_news_editcode.php" method="post">

<div id="page">


<!--- header section start --->
<?php include_once "dash_header1.php" ?>


<?php include_once "dash_nav.php" ?>


<!-- main container -->
<div id="container_p">

   <div id="container">
   
      
       
        <!-- row for matter & quick links -->
       
           <div class="row" style="margin-top:10px; margin-bottom:10px;">
           
           
           
             <!-- right section starts -->  
             
                   <div class="right_section left">
                   
                         <!-- quick links -->
               
							<?php include_once "admin_dash_link.php"; ?>
                             
                          <!-- quick links -->
                       
                   </div>
               
               <!-- right section end -->
           
           
           
             <!-- left section starts -->
             
               <div class="left_section right" >
               
               
                   <div class="matter">
                   
                   
                          <fieldset class="field"><legend>Update Latest News</legend>
            
                                           <div class="welcome_box"> 
                                           
                                               <table  width="100%" cellspacing="5" cellpadding="0" >
                                            
                                                    <tr>
                                                    <td  align="left" valign="top">
                                                    Add News Here<input type="hidden" name="PressNewsId" value="<?php echo $pressnewsid;?>" />
                                                    </td>
                                                    <td >
                                                
                                                    <textarea name="PressNews"  class="text_area" style="width:310px;"><?php echo $pessnews;?></textarea>
                                                    </td>
                                                    
                                                    <td align="right" valign="top">
                                                       <input type="file" name="PressFileName" <?php echo $pressfilename;?> />
                                                    </td>
                     
                                                    <td  align="left" valign="top">
                                                      <a href="#"><input type="image" src="images/submit.png" style="margin-top:5px;" value="update" /></a> 
                                                    </td>
                                                    
                                                    </tr>
                                            
                                            
                                                 </table>
                                                 
                                         </div>
                                             
                          </fieldset>
         
                   </div>
                       
                    <div class="member11">
        
            <table cellspacing="0" cellpadding="0" class="table" >
            <?php include_once "add_Press_NewsShowall.php"; ?>
            

            </table>
        
        </div>
                    
                    
               </div>
               
             <!-- left section end -->
               
             
               
               <div class="clear"></div>
           
           </div>
       
        <!-- row for matter & quick links end-->
  
   </div>

</div>
<!-- main container end -->



<!--- footer section start --->
<?php include_once "dash_footer.php"; ?>

</div>
</form>
</body>

</html>
