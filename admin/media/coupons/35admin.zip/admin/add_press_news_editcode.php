<?php

require "config.php";



	$pressnewsid= $_REQUEST['PressNewsId'];
	$pessnews= $_REQUEST['PressNews'];
	$pressfilename= $_REQUEST['PressFileName'];
	 
	if (($pressnewsid!=""))
	 {
	$sql = "Update  pressnews Set PressNewsId='$pressnewsid',Date=now() Where PressNewsId='$pressnewsid'";
	$qury = mysql_query($sql);
	
	
		if(!$qury )
			echo mysql_error();
		else
		{
	echo "(<script language='javascript'>window.alert('NewsUpdate'),window.location='add_press_News.php'</script>)";
			
		}
	 }
	
 
 else
	 { 
	echo "(<script language='javascript'>window.alert('please fill all details'),window.location='add_press_News.php'</script>)";
			 }




?>