<?php

require 'config.php';
session_start();
$j=    $_SESSION['u_name'];

$oldpass = $_REQUEST['oldpass'];
$newpass = $_REQUEST['newpass'];
$confirmpass = $_REQUEST['confirmpass'];

$sql="select * from admin_acc where UName='$j'and Password='$oldpass'";

	$qury=mysql_query($sql);
	$numrows=mysql_num_rows($qury);
	if($numrows==1)
	{
		
		if($confirmpass==$newpass )
		{
		$sql="update admin_acc set Password=$newpass where UName='$j'and Password='$oldpass'";
		$qury=mysql_query($sql);
			if($qury)
			{
				echo ("<script language='javascript'>window.alert('password updated'),window.location='admin_dashboard.php'</script> ");	
			}
		}
		
		else
		echo ("<script language='javascript'>window.alert('confirm password and new password does not matched $confirmpass and $newpass '),window.location='adm_change_pass.php'</script> ");
	}
	else
	echo ("<script language='javascript'>window.alert('old password does not exist'),window.location='adm_change_pass.php'</script> ");
	
?>