<?php
require "config.php";
$a = $_REQUEST['id'];

 $sql = "delete from    pressnews where PressNewsId='$a'";
	$qury = mysql_query($sql);
		
		if(!$qury )
			echo mysql_error();
		else
		{
	echo "(<script language='javascript'>window.alert('Deleted'),window.location='add_Press_News.php'</script>)";
		}
		

?>