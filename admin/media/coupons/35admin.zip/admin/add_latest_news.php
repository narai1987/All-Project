<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Chhattisgarh Engineering College</title>
<link href="css/style.css" rel="stylesheet" type="text/css" />
<link type="text/css" href="css/menu.css" rel="stylesheet" />
<link href="css/styles.css" rel="stylesheet" type="text/css" />

    
</head>

<body>
<form action="add_latest_newscode.php" method="post">

<div id="page">


<!--- header section start --->
<?php include_once "dash_header1.php" ?>


<!--- container section start --->
   
   <div id="container_p">
   
     <div id="container">
     
     
          <!-- left part links start --->
                             
                  <?php include_once "admin_dash_link.php"; ?>           
                         
                         
            <!-- left part links end ---> 

                             
                             
                         
                         
                       
                
                
          
         
         
         
                  
         <div class="right_part right">
         
         
         
         
         
           <!-- content place holder --->
           
           
           
           
                 <!-- picture gallery --->
     
     
                 <div class="content_row" >
                 
                 
                     <div class="box_head">
                     
                         <div class="box_head_left left"></div>
                         
                         <div class="gallery_head_base left"><h2>Chhattisgarh Engineering College, Welcome's You !</h2></div>
                         
                         <div class="box_head_right right"></div>
                         
                         
                         <div class="clear"></div>
                     
                     </div>
                     
                     <div class="gallery_base_mid">
                     
                     
                        <div class="matter" style="margin:0 10px; padding-top:10px;">
                        
                        
                         
                        
                                
                          
                                       <fieldset class="field"><legend>Add & Update Latest News</legend>
            
                                           <div class="welcome_box"> 
                                           
                                               <table  width="100%" cellspacing="0" cellpadding="0" >
                                            
                                                    <tr>
                                                    <td align="left" valign="top">
                                                    Add News Here
                                                    </td>
                                                    <td  align="left">
                                                    <textarea name="News" class="text_area"></textarea>
                                                    </td>
                     
                                                    <td  align="left" valign="top">
                                                      <a href="#"><input type="image" src="images/submit.png" style="margin-top:5px;" /></a> 
                                                    </td>
                                                    
                                                    </tr>
                                            
                                            
                                                 </table>
                                                 
                                         </div>
                                             
                          </fieldset>
                                        
                                      
                                        
                                       
                                        
                                        
 <!-- DATA GRID START HERE  --->
                                        
                                        
          <!--<div class="detail_heading">
        Total Students <span>(241)</span>
        
           <span class="right" style="margin-top:3px; margin-right:5px;">
           
             Show Item
               <select>
                  <option>5</option>
                  
                  <option>10</option>
                  <option>15</option>
                  <option>20</option>
                  <option>All</option>
               </select>
           </span>
        </div>-->
        
        <div class="member11">
        
            <table cellspacing="1" cellpadding="1" class="table">
            <?php include_once "Admin_latest_news_Showall.php"; ?>
            

            </table>
        
        </div>
                                                
                                                
 <!-- DATA GRID END HERE --->
                                                    
                           
                                        
                                        
                        
                        </div>
                               
                     
                     
                     
                     
                     
                     </div>
                     
                     <div class="gallery_bottom"></div>
                 
                 
                 </div>
                      
      
           <!-- picture gallery end --->
           
           
           
           <!-- content place holder end -->
     
     
     
     
     
     
         </div>
         
         
         <div class="clear"></div>
         
         
         
           
     </div>
   
   </div>

<!--- container section end --->


<!--- footer section start --->
<?php include_once "dash_footer.php"; ?>

</div>
</body>
</form>
</html>
