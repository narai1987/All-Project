<?php

require "config.php";
require "add_new_job.php";
	$title	= $_REQUEST['job_title'];
	
	$qualiy	= $_POST['qualiy_ca'];
	
	$workexp	= $_POST['work_exp'];
	
		$sql="select * from  new_jobpost where job_title='$title'";
     	$qury=mysql_query($sql);
     	$numrows=mysql_num_rows($qury);

		
			/*$titleLenth = strlen($title);*/
			
			if ($numrows==0)
			{
					/*if($titleLenth>100 or $titleLenth<100)
					{
						echo "(<script language='javascript'>window.alert('Job Title only 100 words'),window.location='add_new_job.php'</script>)";
						exit;
					}*/
				
				$sql = "INSERT into new_jobpost values('$title','$qualiy','$workexp')";
				$qury = mysql_query($sql);
	
	
				if(!$qury )
				echo mysql_error();
				else
				{

					echo "(<script language='javascript'>window.alert('inserted'),window.location='add_new_job.php'</script>)";

				}


			}
			else
			{
					echo "(<script language='javascript'>window.alert('This job title Already Exist'),window.location='add_new_job.php'</script>)";

			}
	
?>