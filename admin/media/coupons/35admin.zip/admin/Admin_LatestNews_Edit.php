<?php

require 'config.php';

$a = $_REQUEST['id'];

$sql="select * from latest_news where NewsId='$a'";

	$qury=mysql_query($sql);
	$numrows=mysql_num_rows($qury);
	if($numrows==1)
	{
	
		while($row=mysql_fetch_array($qury))
		{
			
			$newsid=$row[NewsId];
			$News=$row[News];
					
			
		}
	
	}

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Chhattisgarh Engineering College</title>
<link href="css/style.css" rel="stylesheet" type="text/css" />
<link type="text/css" href="css/menu.css" rel="stylesheet" />
<link href="css/styles.css" rel="stylesheet" type="text/css" />

    
</head>

<body>
<form action="Admin_LatestNews_Editcode.php" method="post">

<div id="page">


<!--- header section start --->
<?php include_once "dash_header1.php" ?>


<?php include_once "dash_nav.php" ?>


<!-- main container -->
<div id="container_p">

   <div id="container">
   
      
       
        <!-- row for matter & quick links -->
       
           <div class="row" style="margin-top:10px; margin-bottom:10px;">
           
           
           
             <!-- right section starts -->  
             
                   <div class="right_section left">
                   
                         <!-- quick links -->
               
							<?php include_once "admin_dash_link.php"; ?>
                             
                          <!-- quick links -->
                       
                   </div>
               
               <!-- right section end -->
           
           
           
             <!-- left section starts -->
             
               <div class="left_section right" >
               
               
                   <div class="matter">
                   
                   
                          <fieldset class="field"><legend>Update Latest News</legend>
            
                                           <div class="welcome_box"> 
                                           
                                               <table  width="100%" cellspacing="5" cellpadding="0" >
                                            
                                                    <tr>
                                                    <td  align="left" valign="top">
                                                    Add News Here<input type="hidden" name="NewsId" value="<?php echo $newsid;?>" />
                                                    </td>
                                                    <td >
                                                
                                                    <textarea name="News"  class="text_area"><?php echo $News;?></textarea>
                                                    </td>
                     
                                                    <td  align="left" valign="top">
                                                      <a href="#"><input type="image" src="images/submit.png" style="margin-top:5px;" value="update" /></a> 
                                                    </td>
                                                    
                                                    </tr>
                                            
                                            
                                                 </table>
                                                 
                                         </div>
                                             
                          </fieldset>
         
                   </div>
                       
                    <div class="member11">
        
            <table cellspacing="0" cellpadding="0" class="table" >
            <?php include_once "Admin_latest_news_Showall.php"; ?>
            

            </table>
        
        </div>
                    
                    
               </div>
               
             <!-- left section end -->
               
             
               
               <div class="clear"></div>
           
           </div>
       
        <!-- row for matter & quick links end-->
  
   </div>

</div>
<!-- main container end -->



<!--- footer section start --->
<?php include_once "dash_footer.php"; ?>

</div>
</form>
</body>

</html>
