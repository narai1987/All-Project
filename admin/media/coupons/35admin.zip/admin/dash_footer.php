
              <div id="footer_p" style="height:70px;">
              
                  <div id="footer" style="height:70px;">
                  
                     
                  
                  <div id="copy">
             
                <div class="copy_text left">All Copyright © Reserved by mgmsarni.com | Design & Developed By Mohd Saqib</div>
                
                <div class="right" style="margin-top:25px;"><b style="color:#fff; font-family:Arial, Helvetica, sans-serif;">Visitor No.</b><a href="http://www.designwala.co.in/">
<img src="http://www.easycounter.com/counter.php?saqibm"
border="0" alt="Web Site Hit Counters"></a>
</div>

                <div class="clear"></div>
    
             </div>
                  
                  
                  </div>
              
              </div>