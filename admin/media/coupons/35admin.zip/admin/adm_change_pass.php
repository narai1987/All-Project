<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Welcome to MGMSARNI</title>
<link href="css/style.css" rel="stylesheet" type="text/css" />
<link type="text/css" href="css/menu.css" rel="stylesheet" />
<link href="css/styles.css" rel="stylesheet" type="text/css" />

    
</head>

<body>
<form action="adm_change_passCode.php" method="post">
<div id="page">


<!--- header section start --->
<?php include_once "dash_header1.php" ?>

<?php include_once "dash_nav.php" ?>


<!--- container section start --->
   
   <div id="container_p">
   
     <div id="container">
     
     
           
        <!-- row for matter & quick links -->
       
           <div class="row" style="margin-top:10px; margin-bottom:10px;">
           
           
           
             <!-- right section starts -->  
             
                   <div class="right_section left">
                   
                         <!-- quick links -->
               
							<?php include_once "admin_dash_link.php"; ?>
                             
                          <!-- quick links -->
                       
                   </div>
               
               <!-- right section end -->
           
           
           
             <!-- left section starts -->
             
               <div class="left_section right" >
               
               
                   <div class="matter">
         
     
                                
                          
                                       <fieldset class="field"><legend>Change Password</legend>
            
                                           <div class="welcome_box left"  style="margin-top:10px; margin-left:70px;">
                                           
                                               <table width="100%" border="0" cellspacing="0" cellpadding="0">
 
   
    
 
 <tr>
    <td width="30%">Current Password</td>
    <td width="3%">:</td>
    <td width="67%"><label for="password"></label>
        <input type="password"  class="text_box"  name="oldpass"  id="password"  maxlength="50" size="50" /></td>
  </tr>
  <tr>
    <td>New Password</td>
    <td>:</td>
    <td><label for="password"></label>
        <input type="password"  class="text_box"  name="newpass"  id="password"  maxlength="50" size="50" /></td>
  </tr>
  <tr>
    <td>Confirm Password</td>
    <td>:</td>
    <td><label for="password"></label>
        <input type="password"  class="text_box"  name="confirmpass"  id="password"  maxlength="50" size="50" /></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td><table width="160" border="0" cellspacing="0" cellpadding="4" style="margin-top:10px; margin-bottom:20px">
    
       <tr>
       
        <td width=""></td>
           <td width=""><a href="#"><input type="image" src="images/submit.png" /></a></td>
        <td width=""></td>
    
       </tr>
       
    </table></td>
  </tr>
</table>
                                                 
                                         </div>
                                             
                          </fieldset>
                                        
                                      
                                        
                                       </div>
                                        
                                        
                      
                           
                                        
                                        
                        
                        </div>
                               
                     
                     
                    
                      
      
     
     
     
     
     
         </div>
         
       
         <div class="clear"></div>
         
           
     </div>
   
   </div>

<!--- container section end --->


<!--- footer section start --->
<?php include_once "dash_footer.php"; ?>

</div>
</form>
</body>
</html>
