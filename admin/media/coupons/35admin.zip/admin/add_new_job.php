<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Welcome to MGMSARNI</title>
<link href="css/style.css" rel="stylesheet" type="text/css" />
<link type="text/css" href="css/menu.css" rel="stylesheet" />
<link href="css/styles.css" rel="stylesheet" type="text/css" />

    
</head>

<body>
<form action="add_jobCode.php" method="post">
<div id="page">



<!--- header section start --->
<?php include_once "dash_header1.php" ?>

<?php include_once "dash_nav.php" ?>
<!--- container section start --->
   
   <div id="container_p">
   
     <div id="container">
     
     
       
       
           <div class="row" style="margin-top:10px; margin-bottom:10px;">
           
           
           
             <!-- right section starts -->  
             
                   <div class="right_section left">
                   
                         <!-- quick links -->
               
							<?php include_once "admin_dash_link.php"; ?>
                             
                          <!-- quick links -->
                       
                   </div>
               
               <!-- right section end -->
           
           
           
             <!-- left section starts -->
             
               <div class="left_section right" >
               
               
                   <div class="matter">
         
     
                          
                                       <fieldset class="field"><legend>Add New Jobs</legend>
            
                                           <div class="welcome_box"> 
                                           
                                               <table  width="100%" cellspacing="5" cellpadding="0" >
                                            
                                                    <tr>
                                                    <td align="left" valign="middle">
                                                    Jobs Tittle
                                                    </td>
                                                    <td>
                                                    <input type="text" class="txt_box"  name="job_title"/>
                                                    </td>
                                                    <td align="left" valign="middle">
                                                    Qualification
                                                    </td>
                                                    <td>
                                                    <input type="text" class="txt_box" name="qualiy_ca" />
                                                    
                                                    <td align="left" valign="middle">
                                                    WorK Experience
                                                    </td>
                                                    <td>
                                                    <input type="text" class="txt_box" name="work_exp" />
                                                   
                                                    
                                                    <td align="left" valign="middle">
                                                    <a href="#"><input type="image" src="images/submit.png" /></a>
                                                    </td>
                                                    
                                                    </tr>
                                            
                                            
                                                 </table>
                                                 
                                         </div>
                                             
                          </fieldset>
                                        
                                        
                                        
                          </div>             
                                        
 
         
        
        <div class="member11">
        
            <table cellspacing="1" cellpadding="1" class="table">
            
                <?php include_once "Add_jobShowAllCode.php"; ?>  

            </table>
        
        </div>
                                                
 
                                        
                                        
                        
                        </div>
                               
                     
                     
                     
                     
                    
                 
               
           
           
           <!-- content place holder end -->
     
     
     
     
     
     
         </div>
         
         
         <div class="clear"></div>
         
         
         
           
     </div>
   
   </div>

<!--- container section end --->


<!--- footer section start --->
<?php include_once "dash_footer.php"; ?>

</div>
</form>
</body>
</html>
