
<div class="right_section left">

<div class="head"><h2>Dashboard Links</h2></div>
                        <div class="left_link">
                          
                               <ul>
                               
                                  <li><a href="admin_dashboard.php">Add Latest News</a></li>
                                  
                                   <li><a href="add_Press_News.php">Add News in Brief</a></li>
                                  
                                  <li><a href="add_new_job.php">Add New Jobs</a></li>
                                  
                                 <li><a href="adm_change_pass.php" style="border-bottom:none">Change Password</a></li>
                                
                                  
                 
                               </ul>
          
                          </div>
                          
                          </div>