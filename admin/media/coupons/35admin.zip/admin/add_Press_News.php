<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Welcome to MGMSARNI</title>
<link href="css/style.css" rel="stylesheet" type="text/css" />
<link type="text/css" href="css/menu.css" rel="stylesheet" />
<link href="css/styles.css" rel="stylesheet" type="text/css" />

    
</head>

<body>
<form enctype="multipart/form-data" action="add_Press_NewsCode.php" method="post">

<div id="page">


<!--- header section start --->
<?php include_once "dash_header1.php" ?>

<?php include_once "dash_nav.php" ?>
<!-- main container -->
<div id="container_p">

   <div id="container">
   
      
       
        <!-- row for matter & quick links -->
       
           <div class="row" style="margin-top:10px; margin-bottom:10px;">
           
           
           
             <!-- right section starts -->  
             
                   <div class="right_section left">
                   
                         <!-- quick links -->
               
							<?php include_once "admin_dash_link.php"; ?>
                             
                          <!-- quick links -->
                       
                   </div>
               
               <!-- right section end -->
         
                   <!-- left section starts -->
             
               <div class="left_section right" >
               
               
                   <div class="matter">
         
                                
                          
                                       <fieldset class="field"><legend>Add Press News</legend>
            
                                           <div class="welcome_box"> 
                                           
                                               <table  width="100%" cellspacing="5" cellpadding="0" >
                                            
                                                    <tr>
                                                    <td align="left" valign="top">
                                                    Add  News Heading
                                                    </td>
                                                    <td align="left" valign="top">
                                                    <textarea name="pNews" class="text_area" style="width:310px;" ></textarea>
                                                    </td>
                                                    
                                                    <td align="right" valign="top">
                                                       <input type="file" name="fileUP" />
                                                    </td>
                     
                                                    <td  align="left" valign="top">
                                                       <a href="#"><input type="image" src="images/submit.png" /></a>
                                                    </td>
                                                    
                                                    </tr>
                                            
                                            
                                                 </table>
                                                 
                                         </div>
                                             
                          </fieldset>
                                        
   </div>
        <div class="member11">
        
            <table cellspacing="0" cellpadding="0" class="table">
            
           <?php require "add_Press_NewsShowall.php"; ?>   
               
                

            </table>
        
        </div>
                                                
                                                
 <!-- DATA GRID END HERE --->
                                                    
                           
                                        
                                        
                        
                        </div>
                               
                     
                     
                     
                     
                     
                     
      
         
         
         <div class="clear"></div>
         
         
         
           
     </div>
   
   </div>

<!--- container section end --->


<!--- footer section start --->
<?php include_once "dash_footer.php"; ?>

</div>
</form>
</body>
</html>
