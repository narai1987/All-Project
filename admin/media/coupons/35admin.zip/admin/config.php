<?php

ini_set('SMTP', 'mail.myt.mu');
/*define('EMAIL', 'email@gmail.com');*/
DEFINE('WEBSITE_URL', 'http://mgmsarni.com');
$conn = mysql_connect('localhost','mgmsaqib','12345');
$db   = mysql_select_db('mgm_sarni',$conn);
?>