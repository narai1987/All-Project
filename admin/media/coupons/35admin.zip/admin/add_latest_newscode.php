<?php

require "config.php";
require "admin_dashboard.php";



	$news	= $_REQUEST['News'];
		
	if (($news!=""))
	 {
	$sql = "INSERT into latest_news (News,Date) values('$news',now())";
	$qury = mysql_query($sql);
	
	
		if(!$qury )
			echo mysql_error();
		else
		{
	echo "(<script language='javascript'>window.alert('inserted'),window.location='admin_dashboard.php'</script>)";
			
		}
	 }
	
 
 else
	 { 
	echo "(<script language='javascript'>window.alert('please fill all details'),window.location='admin_dashboard.php'</script>)";
			 }




?>