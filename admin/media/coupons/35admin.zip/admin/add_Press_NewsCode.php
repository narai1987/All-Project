

<?php



$News		= $_REQUEST['pNews'];
			    
	$File	= addslashes(file_get_contents($_FILES['fileUP']['tmp_name']));

$fname = $_FILES["fileUP"]["name"] ;

$ftype = $_FILES["fileUP"]["type"] ;




	

if($fname=="")

{


echo ("<script language='javascript'>window.alert('enter all details'),window.location='add_Press_News.php'</script>");
exit;

}
if ($_FILES["UpFile"]["error"] > 0)
  {
  echo "Error: " . $_FILES["UpFile"]["error"] . "<br />";
  }
else
  {
  
  }
  
  
   $target = "PressNews/"; 
 $target = $target . basename( $_FILES['fileUP']['name']) ; 
 $ok=1; 
 
 //This is our size condition 
 if ($uploaded_size > 350000) 
 { 
 echo "Your file is too large.<br>"; 
 $ok=0; 
 } 
 
 //This is our limit file type condition 
 if ($uploaded_type =="text/php") 
 { 
 echo "No PHP files<br>"; 
 $ok=0; 
 } 
 
 //Here we check that $ok was not set to 0 by an error 
 if ($ok==0) 
 { 
 Echo "Sorry your file was not uploaded"; 
 exit;
 } 
 
 //If everything is ok we try to upload it 
 else 
 { 
 if(move_uploaded_file($_FILES['fileUP']['tmp_name'], $target)) 
 { 
 #echo "The file ". basename( $_FILES['UpFile']['name']). " has been uploaded"; 
 } 
 else 
 { 
 echo "Sorry, there was a problem uploading your file.  $ftype"; 
 exit;
 } 
 }


require 'config.php';


	
	
	
$sql = "INSERT into  pressnews (PressNews,Date,PressFileName,PressFtype) values('$News',now(),'$fname','$ftype')";
	$qury = mysql_query($sql);
	
	
		if(!$qury )
			echo mysql_error();
		else
		{
				echo ("<script language='javascript'>window.alert('Your press release updated on website.Please visit home page'),window.location='add_press_news.php'</script>");
			
		}


?>