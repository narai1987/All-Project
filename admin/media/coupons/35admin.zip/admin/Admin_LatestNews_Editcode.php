<?php

require "config.php";



	$newsval	= $_REQUEST['News'];
	$newsId= $_REQUEST['NewsId'];
	
	 
	if (($newsval!=""))
	 {
	$sql = "Update  latest_news Set News='$newsval',Date=now() Where NewsId='$newsId'";
	$qury = mysql_query($sql);
	
	
		if(!$qury )
			echo mysql_error();
		else
		{
	echo "(<script language='javascript'>window.alert('NewsUpdate'),window.location='admin_dashboard.php'</script>)";
			
		}
	 }
	
 
 else
	 { 
	echo "(<script language='javascript'>window.alert('please fill all details'),window.location='admin_dashboard.php'</script>)";
			 }




?>