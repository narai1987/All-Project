
<div id="container">
<!--<div id="header"></div>-->

<div id="content">

<div class="my_account">
<div class="booktrip">
<h2><span>Cart Detail</span></h2>

<div class="scedule">
<fieldset class="bookField">

<legend>Trip Pricing</legend>

<table width="100%" cellpadding="0" cellspacing="0">
<tr class="cart_font">
<td class="cart_bob" width="45%"><strong>Items</strong></td>
<td class="cart_bob" width="20%"><strong>Qty</strong></td>
<td class="cart_bob" align="center"><strong>Price</strong></td>
</tr>
<?php foreach($equipments as $equipment) { ?>
<tr>
<td class="cart_bob"><strong><?php echo $equipment['equipment'];?></strong></td>
<td class="cart_bob">
<select class="qty">
<?php for($i=0;$i<20;$i++) { ?>
<option value="<?php echo $i;?>" <?php echo ($i==$equipment['no_of_equipment'])?("selected=selected"):("");?>><?php echo $i;?></option>
<?php } ?>
</select>
</td>
<td class="cart_bob price" align="right"><?php echo $equipment['eq_prices'];?>THB</td>
</tr>
<?php } ?>
<?php foreach($cabins as $cabin) { ?>
<tr>
<td class="cart_bob"><strong><?php echo $cabin['cabin'];?></strong></td>
<td class="cart_bob">
<select class="qty">
<?php for($i=0;$i<20;$i++) { ?>
<option value="<?php echo $i;?>" <?php echo ($i==$cabin['no_of_cabin'])?("selected=selected"):("");?>><?php echo $i;?></option>
<?php } ?>
</select>
</td>
<td class="cart_bob price" align="right"><?php echo $cabin['cabin_price'];?>THB</td>
</tr>
<?php } ?>
<?php foreach($foods as $food) { ?>
<tr>
<td class="cart_bob"><strong><?php echo $food['food'];?></strong></td>
<td class="cart_bob">
<select class="qty">
<?php for($i=0;$i<20;$i++) { ?>
<option value="<?php echo $i;?>" <?php echo ($i==$food['no_of_qty'])?("selected=selected"):("");?>><?php echo $i;?></option>
<?php } ?>
</select>
</td>
<td class="cart_bob price" align="right"><?php echo $food['food_price'];?>THB</td>
</tr>
<?php } ?>
<?php foreach($beverages as $beverage) { ?>
<tr>
<td class="cart_bob"><strong><?php echo $beverage['beverage'];?></strong></td>
<td class="cart_bob">
<select class="qty">
<?php for($i=0;$i<20;$i++) { ?>
<option value="<?php echo $i;?>" <?php echo ($i==$beverage['no_of_qty'])?("selected=selected"):("");?>><?php echo $i;?></option>
<?php } ?>
</select>
</td>
<td class="cart_bob price" align="right"><?php echo $beverage['beverage_price'];?>THB</td>
</tr>
<?php } ?>

<?php foreach($persons as $person) { ?>
<tr>
<td class="cart_bob"><strong>Persons</strong></td>
<td class="cart_bob">
<select class="qty">
<?php for($i=0;$i<20;$i++) { ?>
<option value="<?php echo $i;?>" <?php echo ($i==$person['no_of_person'])?("selected=selected"):("");?>><?php echo $i;?></option>
<?php } ?>
</select>
</td>
<td class="cart_bob price" align="right"><?php echo ($person['no_of_person']*$person['trip_price']);?>THB</td>
</tr>
<?php } ?>
<?php
print_r($persons); foreach($$childs as $$child) { ?>
<tr>
<td class="cart_bob"><strong>Childs</strong></td>
<td class="cart_bob">
<select class="qty">
<?php for($i=0;$i<20;$i++) { ?>
<option value="<?php echo $i;?>" <?php echo ($i==$$child['no_of_child'])?("selected=selected"):("");?>><?php echo $i;?></option>
<?php } ?>
</select>
</td>
<td class="cart_bob price" align="right"><?php echo ($$child['no_of_child']*$$child['trip_price']);?>THB</td>
</tr>
<?php } ?>

<tr>
<td class="cart_bob"><strong>Tax</strong></td>
<td class="cart_bob"><?php echo $tax;?>%</td>
<td class="cart_bob price" align="right">100:00 THB</td>
</tr>

<tr>
<td colspan="2" align="right" class="cart_bob cart_font"><strong>Total :</strong></td>
<td class="cart_bob price" align="right">36000:00 THB</td>
</tr>
<tr>
<td colspan="2" align="right" class="cart_bob cart_font"><strong>Grand Total :</strong></td>
<td class="cart_bob price" align="right">36000:00 THB</td>
</tr>

<tr>
<td colspan="3" align="center" valign="bottom"><button class="lang_button"><strong>Proceed to Checkout</strong></button></td>
</tr>

</table>





</fieldset>


</div>


</div>
</div>

</div>
</div>