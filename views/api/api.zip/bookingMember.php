<div id="container">
<div id="content">
<form name="frmMember" action="webview.php" method="post" onsubmit="return bMember();">
<div class="my_account">
<div class="booktrip">
<h2><span>Trip (Schedule)</span></h2>
<p><select class="date_trip left" name="start_date" id="start_date" onChange="tripDateTime(this.value,'1','<?php echo $_REQUEST['tripId'];?>')">
<option>Start Date</option>
<?php foreach($schedules as $schedule) { ?>
<option value="<?php echo $schedule['id'];?>"><?php echo $schedule['start_date'];?></option>
<?php }?>
</select> <select class="date_trip right" name="end_date" id="end_date" onChange="tripDateTime(this.value,'2','<?php echo $_REQUEST['tripId'];?>')">
<option>Start Date</option>
<?php foreach($schedules as $schedule) { ?>
<option value="<?php echo $schedule['id'];?>"><?php echo $schedule['end_date'];?></option>
<?php }?>
</select></p>
<div class="scedule">
<fieldset class="bookField">
<legend>Member/Person</legend>
<table cellspacing="0" cellpadding="0" class="tabls">
<tr>
<td width="30%">No. of Adults:</td>
<td><select class="person" name="adult" id="adult" onChange="divPerson(this.value,child.value)">
<?php for($i=0;$i<20;$i++){ ?>
<option value="<?php echo $i;?>"><?php echo $i;?></option>
<?php }?>
</select></td>
</tr>

<tr>
<td width="30%">No. of Child:</td>
<td><select class="person" name="child" id="child" onChange="divPerson(adult.value,this.value)">
<?php for($i=0;$i<20;$i++){ ?>
<option value="<?php echo $i;?>"><?php echo $i;?></option>
<?php }?>
</select></td>
</tr>

</table>

</fieldset>

<fieldset class="bookField">
<legend>Member Details</legend>

<div class="main_collaps" id="memberCollaps">

</div>

</fieldset>
</div>


</div>
</div>
   

<table width="100%" cellpadding="0" cellspacing="0" class="tab_button">
    <tr>
        <td align="right" >
        <button class="lang_button"><strong>Submit</strong></button>
        <button class="lang_button_re">&nbsp; <strong>Reset</strong></button>
        <input type="hidden" name="control" value="api"  />
        <input type="hidden" name="task" value="saveMember"  />
        <input type="hidden" name="tripId" value="<?php echo $_REQUEST['tripId'];?>"  />
        <input type="hidden" name="userId" id="userId" value="<?php echo $_REQUEST['userId'];?>"  />
        </td>
    </tr>
    
</table>
</form>
</div>
</div>