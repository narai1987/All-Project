<?php
$_REQUEST['control'] = "service";
$_REQUEST['task'] = "filter";
	require_once("../controller.php");
if(count($results)) {
?>



<div class="advance_prov">


<div class="ad_search_pro">

<ul>
<?php
foreach($results as $result) { ?>
    <li><a href="index.php?control=provider&task=search&service=<?php echo $result['id'];?>&tmpid=1"><?php echo $result['service'];?></a></li>
<?php
} ?>
</ul>
</div>
</div>
  <?php

}