<?php
$_REQUEST['control'] = "provider";
$_REQUEST['task'] = "subscribe";
$_REQUEST['subscribe'] = $_REQUEST["email"];
require_once("../controller.php");
?>