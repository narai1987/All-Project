<?php
$_REQUEST['control'] = "provider";
$_REQUEST['task'] = "getstate";
$_REQUEST['country_id'] = $_REQUEST["country_id"];
	require_once("../controller.php");
if(count($results)) {
	?>
	<option value="0">Select State</option>			
	<?php	
	foreach($results as $result) {
		?>
        <option value="<?php echo $result['id'];?>"><?php echo $result['state'];?></option>
		<?php	
	}
}
else {
	$_REQUEST['country_id'] = '';
	require_once("../controller.php");
	if(count($results)) {
		?>
		<option value="0">Select State</option>			
		<?php	
		foreach($results as $result) {
			?>
			<option value="<?php echo $result['id'];?>"><?php echo $result['state'];?></option>
			<?php	
		}
	}
	else {
		?>
		<option value="0">Select State</option>			
		<?php
	}
}