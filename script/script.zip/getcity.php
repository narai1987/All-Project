<?php
session_start();
$_REQUEST['control'] = "provider";
$_REQUEST['task'] = "getcity";
$_REQUEST['state_id'] = $_REQUEST["state"];
$_SESSION['mystate'] = 0;
$_SESSION['mystate'] = $_REQUEST["state"];
//file_put_contents("text.txt",$_SESSION['mystate']);
	require_once("../controller.php");
if(count($results)) {
	?>
	<option value="0">Select Suburb</option>			
	<?php	
	foreach($results as $result) {
		?>
        <option value="<?php echo $result['id'];?>"><?php echo $result['city'];?></option>
		<?php	
	}
}
else {
	$_REQUEST['state_id'] = '';
	require_once("../controller.php");
	if(count($results)) {
		?>
		<option value="0">Select Suburb</option>			
		<?php	
		foreach($results as $result) {
			?>
			<option value="<?php echo $result['id'];?>"><?php echo $result['city'];?></option>
			<?php	
		}
	}
	else {
		?>
		<option value="0">Select Suburb</option>			
		<?php
	}
}