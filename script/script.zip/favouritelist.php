<?php
	$_REQUEST['control'] = "provider";
	$_REQUEST['task'] = "favouriteList";
	$_REQUEST['state_id'] = $_REQUEST["state"];
	require_once("../controller.php");
	require_once("../textconfig/config.php");
	session_start();
	?>
	
        <div class="heading_cart"><h3>Selected Provider<?php if((count($results))&&(count($results)!="1")) {?>s<?php }?><span id="countp"> (<?php echo count($results);?>)</span></h3> </div>
        <div class="bag_container" style="max-height:300px; overflow:auto;">
            
            <table width="100%" cellspacing="0" cellpadding="0" class="bag_tab">
            <?php
			if(count($results)) {
			foreach($results as $result) {
				$image = $result['image']?$result['image']:"items.png";
				?>
                <tr>
                <td width="20%" align="center"><a href="index.php?control=provider&task=detail&provider_id=<?php echo $result['provider_id'];?>&service_id=<?php echo $result['service_id'];?>&tmpid=4"><img src="images/provider/<?php echo $image;?>" width="70" alt="Provider" title="<?php echo $result['fname']." ".$result['lname'];?>" /></a></td>
               <!-- <td width="30%"><a href="index.php?control=provider&task=detail&provider_id=<?php echo $result['provider_id'];?>&service_id=<?php echo $result['service_id'];?>&tmpid=4"><strong><?php echo $result['fname']." ".$result['lname'];?></strong></a></td>-->
                <td width="40%"><a href="index.php?control=provider&task=detail&provider_id=<?php echo $result['provider_id'];?>&service_id=<?php echo $result['service_id'];?>&tmpid=4" title="Service"><strong><?php echo $result['service'];?></strong></a></td>
                <!--<td align="center" width="20%"><span><strong>$<?php echo $result['hr_rate'];?></strong></span></td>-->  
                <td width="5%"><a style="cursor:pointer;" onclick="setfavourite('<?php echo $_SESSION['userid'];?>','<?php echo $result['provider_id'];?>','<?php echo $result['service_id'];?>')" ><img src="images/del.png" title="Remove from list"  /></a></td>          
                </tr> 
                <?php 
				}
			}
			else {
				?>
                <tr>
                	<td colspan="3"><?php echo NOFAVOURITE;?></td>
                </tr>
                <?php
			}
				?>                             
            </table>
        
        </div>