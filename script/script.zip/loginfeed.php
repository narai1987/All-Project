<?php
$_REQUEST['control'] = "service";
	require_once("../controller.php");