<?php
$_REQUEST['task'] = "feed";
	require_once("../controller.php");
	echo $results;