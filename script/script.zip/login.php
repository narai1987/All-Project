<?php
$_REQUEST['control'] = "provider";
$_REQUEST['task'] = "login";
$_REQUEST['email'] = $_REQUEST["email"];
$_REQUEST['password'] = $_REQUEST["password"];
$_REQUEST['usertype'] = $_REQUEST["usertype"];
	require_once("../controller.php");