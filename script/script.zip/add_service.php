<?php

$_REQUEST['control'] = "providersaccount";
$_REQUEST['task'] = "getstate";
require("../controller.php");

$states = $results;
$results = "";

$_REQUEST['control'] = "providersaccount";
$_REQUEST['task'] = "addservice";
require("../controller.php");/*
$_REQUEST['task'] = "addservice_add";
require_once("../controller.php");*/
$resultss = $results;
?>

 <fieldset class="service_field" >
   <div class="service_head_p">
        
   <p>Add New Service</p></div>
    
    <form method="post" action="index.php" name="addService" onsubmit="return addnew_validation();">  
        <table width="98%" cellpadding="0" cellspacing="2" class="tab_regis">
                    <tr>
                    <td align="right" width="30%" valign="top"><strong><em class="star_red">*</em>Service Name :</strong></td>
                    <td colspan="2">
                  
                    <select class="reg_txt" name="service" id="service_name">
                    <option value="0">Select Service</option>
                     <?php 
                        //while($data_sn = mysql_fetch_array($se)){	
                        foreach($resultss as $add_spro) {  
                       ?>
                        <option value="<?php echo $add_spro['id'] ?>" <?php if($add_spro['id'] == $_REQUEST['service']){ ?> selected="selected" <?php } ?>>
						<?php echo $add_spro['service'] ?></option>
                        <?php } ?>
                    <!--<option>XYZ</option>
                    <option>PQR</option>-->
                    </select>
                    <span id="msgservice_name" style="color:red;" class="font"> </span>
                    </td>
                    
                  </tr>
                    <!--<tr>
                    <td align="right" valign="top"><strong><em class="star_red">*</em>Service Price :</strong></td>
                    <td><input type="text" class="reg_txt" name="price" id="price" onkeyup="priceFor(this.value,this.id)"  />
                        <span id="msgprice" style="color:red;" class="font"> </span> 
                    </td>                    
                    <td width="15%">&nbsp;</td>
                    
                  </tr>-->
                   <!-- <tr height="20px">
                    <td align="right"></td>
                    <td colspan="2">
                    <a href="#" class="font2">Lucknow</a>
                    </td>
                    
                  </tr>-->
                  <tr>
                    <td align="right" width="30%" valign="top"><strong><em class="star_red">*</em>Service Name :</strong></td>
                    <td colspan="2">
                  
                    <select class="reg_txt" name="state" id="state" onchange="getcitybystate(this.value)">
                    <option value="0">Select state</option>
                     <?php 
					
                        foreach($states as $state) {  
                       ?>
                        <option value="<?php echo $state['id'] ?>" <?php if($state['id'] == 9){ ?> selected="selected" <?php } ?>>
						<?php echo $state['state'] ?></option>
                        <?php } ?>
                    <!--<option>XYZ</option>
                    <option>PQR</option>-->
                    </select>
                    <span id="msgstate_name" style="color:red;" class="font"> </span>
                    </td>
                    
                  </tr>
                  
                   <tr height="20px">
                    <td align="right"></td>
                    <td colspan="2"><ul id="showcity" class="service_name">
</ul>
                    <!--<a href="#" class="font2">Lucknow</a>-->
                    </td>
                    
                  </tr>
                  
                    <tr>
                <td align="right" valign="top"><strong><em class="star_red">*</em>Service City :</strong></td>
                <td colspan="2">
                <?php 
                $sql3="SELECT * FROM cities where status = '1'"; 
                $city=mysql_query($sql3);
                //echo mysql_num_rows($city);
                ?>
                
                <div class="maincombo">
                <ul>
    	<li onclick="opendrop()">Select City</li>
    	<li>
        	<ul id="uldrop">
            <!-- <?php 
                while($data_city = mysql_fetch_array($city)){
                ?>
            	<li><input type="checkbox" name="chk<?php echo $data_city['id']; ?>" id="chk<?php echo $data_city['id']; ?>" value="<?php echo $data_city['id']; ?>" onchange="selectcity('<?php echo $data_city['id']; ?>','<?php echo $data_city['city']; ?>')"  />&nbsp;&nbsp;&nbsp;<?php echo $data_city['city']; ?></li>
            	<?php } ?>
                <input type="hidden" name="hdncity" id="hdncity" value=""  />-->
            </ul>
        </li>
    </ul>
                
                 </div>
                </td>
            
            </tr>
                  
                  <tr>
                    <td align="right"></td>
                    <td colspan="2"> <span id="msgcity_name" style="color:red;" class="font"> </span> 
                    </td>
                    
                  </tr>
                 
                    <tr>
                    <td align="right"><strong>Description :</strong></td>
                    <td colspan="2">
                    <textarea class="regis_area" rows="2" cols="5" name="description" id="description" ></textarea>
                    </td>
                    
                  </tr>
                  <tr>
                    <td align="right"></td>
                    <td colspan="2" align="right" style="padding:10px 10px 0 0;">
                    	<input class="submit" type="submit" name="save" value="Save" />  
                    	<!--<input class="button" type="submit" name="save" value="Save" onclick="addnew_validation()" />-->                    
                    </td>
                    
                  </tr>
                  
                  
                  </table>
        <input type="hidden" name="control" value="providersaccount" />
        <input type="hidden" name="view" value="provideraccount" />
        <input type="hidden" name="task" value="addservice_add" />                
        <input type="hidden" name="tmpid" value="5" />
    </form>
                  
 </fieldset>