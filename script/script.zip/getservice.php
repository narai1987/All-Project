<?php

$_REQUEST['control'] = "service";
$_REQUEST['task'] = "getservice";
$_REQUEST['str'] = $_REQUEST["str"];
require_once("../controller.php");
//echo count($results);
?>
<div class="providerbox" id="search_service">
        <div id="mygallery" class="stepcarousel">
            <div class="belt">
                <div class="panel">
                <?php
                $i = 0;
                foreach($results as $result) {
                    $i++;
                    ?>
                    <div class="tech_icon">
                    <p>
                    <strong>Service :</strong> <a href="#"> <?php echo $result['service'];?> </a><br>
                    <strong>Description:</strong> 
                   <?php echo $result['description'];?>
                    
                    </p>
                   
                    </div>
                <?php
                	if($i%6==0) {
                    ?>
                    	</div><div class="panel">
                <?php
					}
				}
            ?>
            </div>
            </div>
        </div>
    </div>