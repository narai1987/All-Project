<?php
	ob_start();
date_default_timezone_set("Asia/Calcutta");
$_REQUEST['control'] = "provider";
$_REQUEST['task'] = "servicechang";

	require_once("../controller.php");
	foreach($results as $pservice);
	?>
    <table cellpadding="1" cellspacing="1" width="100%">
    <tr>
    <td width="20%" align="justify" valign="top"><strong>Service </strong></td>
	 <td width="2%" valign="top"><strong>:</strong></td>
    <td valign="top"><?php echo $pservice['service'];?></td>
    </tr> 
    <!-- <tr>
    <td align="right"><strong>Price :</strong></td>
    <td><span><strong>$<?php echo $pservice['hr_rate'];?></strong></span></td>
    </tr>-->
     <tr>
    <td align="justify" valign="top"><strong>Suburbs </strong></td>
    <td valign="top"><strong>:</strong></td>
    <td valign="top"><?php
	
	$city_data = $ob->getCityByService($_REQUEST['provider_id'],$_REQUEST['service_id']);
	if(count($city_data)) {
		foreach($city_data as $city) {
		 $cities .= $cities?' , '.$city['city']:$city['city'];
		}
	}
	 echo $cities;
	 ?></td>
    </tr>
     <?php
	if($pservice['description']) {
	?>
    <tr>
    <td align="justify" valign="top"><strong>Description </strong></td>
    <td valign="top"><strong>:</strong></td>
    <td valign="top" ><?php echo $pservice['description'];?></td>
    </tr>
    <?php }?>
    <tr height="30px" valign="bottom">
    <td align="justify"></td>    
    <td></td>
    <td align="right" id="add_remove_butt_td">
    <?php 
	
	session_start();
	if($_SESSION['usertype']==2) {
		try {
			$check = $ob->checkfavourite($_SESSION['userid'],$_REQUEST['provider_id'],$_REQUEST['service_id']);
		}
		catch(Exception $e) {
			$check = $db->checkfavourite($_SESSION['userid'],$_REQUEST['provider_id'],$_REQUEST['service_id']);
		}
		if(!count($check)) {
	?>
    <a onclick="setfavourite('<?php echo $_SESSION['userid'];?>','<?php echo $_REQUEST['provider_id'];?>','<?php echo $_REQUEST['service_id'];?>')"><img src="template/sp_detail/images/addtocart.png" alt="add to cart" /></a>
    <?php
		}
		else {
			?><a  onclick="setfavourite('<?php echo $_SESSION['userid'];?>','<?php echo $_REQUEST['provider_id'];?>','<?php echo $_REQUEST['service_id'];?>')"><img src="template/sp_detail/images/remove_whishlist.png" alt="add to cart" /></a>
            <?php	
		}
	}
	?>
    </td>
    </tr>
      
    </table>   
    <?php
	ob_flush(); 