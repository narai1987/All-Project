<?php
session_start();
$_REQUEST['control'] = "provider";
$_REQUEST['task'] = "getpcode";
$_REQUEST['city_id'] = $_REQUEST["city"];
$_SESSION['mystate'] = 0;
$_SESSION['mystate'] = $_REQUEST["state"];
//file_put_contents("text.txt",$_SESSION['mystate']);
	require_once("../controller.php");
echo $results[0]['pcode'];