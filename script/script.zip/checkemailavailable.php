<?php
$_REQUEST['task'] = "checkemailavailable";
	require_once("../controller.php");
	echo $results;