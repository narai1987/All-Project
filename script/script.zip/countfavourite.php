<?php
date_default_timezone_set("Asia/Calcutta");
$_REQUEST['control'] = "provider";
$_REQUEST['task'] = "countfavourite";/*
$_REQUEST['provider_id'] = $_REQUEST["email"];
$_REQUEST['password'] = $_REQUEST["password"];
$_REQUEST['usertype'] = $_REQUEST["usertype"];*/
	require_once("../controller.php");
	echo count($results);
	