<?php

date_default_timezone_set("Asia/Calcutta");
$_REQUEST['control'] = "provider";
$_REQUEST['task'] = "setrate";/*
$_REQUEST['provider_id'] = $_REQUEST["email"];
$_REQUEST['password'] = $_REQUEST["password"];
$_REQUEST['usertype'] = $_REQUEST["usertype"];*/
	require_once("../controller.php");
	?>
    <style type="text/css">
	<?php if($_SESSION['alert'] == 6) { ?>
		.alert_boxes_green1 {
			display:block;
		}
	<?php  } ?>
	<?php if($_SESSION['alert'] == 7) { ?>
		.alert_boxes_yellow1 {
			display:block;
		}
	<?php  } ?>
	</style>
      <p>
    <?php
	if($_SESSION['alert'] == 6) {
		?>
   <strong>Success  Message</strong><br />
		<?php
	}
	else {
		?>
    <strong>Worning Message</strong><br />
		<?php
	}
	?>
                    <?php if($_SESSION['alert'] == 6) echo $_SESSION['message'];
					?>
                    </p>