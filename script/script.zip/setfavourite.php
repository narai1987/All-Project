<?php

	date_default_timezone_set("Asia/Calcutta");
	$_REQUEST['control'] = "provider";
	$_REQUEST['task'] = "setfavourite";
	
	require_once("../controller.php");
	?>
    <style type="text/css">
	<?php if($_SESSION['alert'] == 1) { ?>
		.alert_boxes_green {
			display:block;
		}
	<?php  } ?>
	<?php if($_SESSION['alert'] == 2) { ?>
		.alert_boxes_yellow {
			display:block;
		}
	<?php  } ?>
	</style>
     <p>
    <?php
	if($_SESSION['alert'] == 1) {
		?>
   <strong>Success  Message</strong><br />
		<?php
	}
	else {
		?>
    <strong>Worning Message</strong><br />
		<?php
	}
	?>
                    <?php if($_SESSION['alert'] == 1) echo $_SESSION['message'];
					?>
                    </p>
    
	