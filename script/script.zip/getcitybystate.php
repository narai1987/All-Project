<?php 

$_REQUEST['control'] = "providersaccount";
$_REQUEST['task'] = "getcitybystate";

require("../controller.php");

foreach($results as $data_city) {  
                //while($data_city = mysql_fetch_array($city)){
                ?>
            	<li><input type="checkbox" name="chk<?php echo $data_city['id']; ?>" id="chk<?php echo $data_city['id']; ?>" value="<?php echo $data_city['id']; ?>" onchange="selectcity('<?php echo $data_city['id']; ?>','<?php echo $data_city['city']; ?>')"  />&nbsp;&nbsp;&nbsp;<?php echo $data_city['city']; ?></li>
            	<?php } ?>
                <input type="hidden" name="hdncity" id="hdncity" value=""  />