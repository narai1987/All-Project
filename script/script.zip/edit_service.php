<?php

$_REQUEST['control'] = "providersaccount";
$_REQUEST['task'] = "editservice";
require_once("../controller.php");
$_REQUEST['task'] = "updateservice";
require_once("../controller.php");
$_REQUEST['task'] = "deleteservice";
require_once("../controller.php");
$_REQUEST['task'] = "addcityservice";
require_once("../controller.php");
$_REQUEST['main_id'] = $_REQUEST["main_id"];
require_once("../controller.php");
?>

 <fieldset class="service_field" >
   <div class="service_head_p">
        
   <p>Edit Service</p></div>
    
    <form method="post" action="index.php" onsubmit="return editservices()">  
        <table width="98%" cellpadding="0" cellspacing="2" class="tab_regis">
            <tr>
                <td align="right" width="30%"><strong>Service Name :</strong></td>
                <td colspan="2">
                <?php  
                //$s_updates = $ob->getServiceEdit($result['main_id']);
                foreach($results as $s_edit) { 
                
                echo $s_edit['service']." ";
                
                
                
                } ?>
                <input type="hidden" name="id" value="<?php  echo $s_edit['service']; ?>" />
                <input type="hidden" name="service_id" value="<?php  echo $s_edit['service_id']; ?>" />
                <input type="hidden" name="soid" value="<?php  echo $_REQUEST['main_id']; ?>" />
                <input type="hidden" name="control" value="providersaccount" />
                <input type="hidden" name="view" value="provideraccount" />
                <input type="hidden" name="task" value="updateservice" />
                
                <input type="hidden" name="tmpid" value="5" />
                </td>
            
            </tr>
           <!-- <tr>
                <td align="right" valign="top"><strong>Service Price :</strong></td>
                <td><input type="text" class="reg_txt" name="rate" id="price" value="<?php echo $s_edit['hr_rate']; ?>"  onkeyup="priceFor(this.value,this.id)"  />
                    <span id="msgprice" style="color:red;" class="font"> </span> 
                </td>                    
                <td width="15%">&nbsp;</td>
            
            </tr> -->      
               <tr height="20px">
                    <td align="right"></td>
                    <td colspan="2">
                    <ul id="showcity" class="service_name">
                <?php
				$my_sql="SELECT c.* FROM cities c JOIN service_city sc ON c.id = sc.city_id WHERE sc.provider_id = '".$s_edit['provider_id']."' and service_id = '".$s_edit['service_id']."'";
				 $myresult = mysql_query($my_sql);
				 $cityidss = '';
				 while($mycity = mysql_fetch_array($myresult)){
					 $idcity[] = $mycity['id'];
					 $cityidss .= $cityidss?",".$mycity['id']:$mycity['id'];
				 
				 ?> 
                        <li id="li<?php echo $mycity['id']?>"><?php echo $mycity['city']?> <a onclick="deleteelement('<?php echo $mycity['id'];?>')"> 
                        <img src="images/cross_small.png"></a> </li>
                        
                  <?php
				  }
				  ?>
                    </ul>
                    <!--<a href="#" class="font2">Lucknow</a>-->
                    </td>
                    
                  </tr>
                        
            <tr>
                <td align="right"><strong>Service City :</strong></td>
                <td colspan="2">
                <?php 
                
				
				$sql3="SELECT * FROM cities where status = '1'"; 
                $city=mysql_query($sql3);
                
                ?>
                
               <div class="maincombo">
                <ul>
                    <li onclick="opendrop()">Select City</li>
                    <li>
                        <ul id="uldrop" >
                         <?php 
                            while($data_city = mysql_fetch_array($city)){
                            ?>
                            <li><input type="checkbox" name="chk<?php echo $data_city['id']; ?>" id="chk<?php echo $data_city['id']; ?>" value="<?php echo $data_city['id']; ?>" onchange="selectcity('<?php echo $data_city['id']; ?>','<?php echo $data_city['city']; ?>')" <?php if(in_array($data_city['id'],$idcity)) {?> checked="checked" <?php }?>  />&nbsp;&nbsp;&nbsp;<?php echo $data_city['city']; ?></li>
                            <?php } ?>
                            
                        </ul>
                    </li>
                    <li></li>
                </ul>
                 
                 </div>
                </td>
            
            </tr>
            <tr>
            	<td></td>
            	<td><span id="msgcity_name" style="color:red;" class="font"> </span> </td>
            </tr> 
            <tr>
            	<td></td>
            	<td><input type="hidden" name="hdncity" id="hdncity" value="<?php echo $cityidss;?>"  /></td>
            </tr>     
                      
            <tr>
                <td align="right"><strong>Description :</strong></td>
                <td colspan="2">
                <textarea class="regis_area" rows="2" name="description" cols="5"><?php echo $s_edit['description'];?></textarea>
                </td>
                
                </tr>
                <tr>
                	<td align="right"></td>
                    <td colspan="2" align="right" style="padding:10px 10px 0 0;">
                    	<input class="submit" type="submit" name="save" value="Update" />                    
                    </td>            
            	</tr>
                      
                      
        	</table>
    </form>
                  
 </fieldset>